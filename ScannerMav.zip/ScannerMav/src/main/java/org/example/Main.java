package org.example;

import
        java.io.IOException;
import java.io.OutputStream;
import java.net.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import static java.lang.Math.round;

class Main {
    static ArrayList<String> codeList = new ArrayList<>();
    static ArrayList<String> nameList = new ArrayList<>();
    static ArrayList<String> priceList = new ArrayList<>();
    static ArrayList<Product> productList = new ArrayList<>();

    static int platnosc = 0;
    static int cardNum = 0;

    static int blikNum = 0;
    static int cvv = 0;
    static String exp_date = "";
    static double priceSum = 0;

    static String keyboardInput;
    public static void main(String[] args) throws Exception {
        System.out.println("Przykładowe kody: \n5449000011527\n5449000000996");
        Scanner scan = new Scanner(System.in);
        dbConnect connection = new dbConnect();
        codeList = connection.getData();
        nameList = connection.getName();
        priceList = connection.getPrice();


        while(true) {
            if(platnosc != 0) {
                if(platnosc == 1){
                    priceSum = priceSum + getSumPrice();
                    System.out.println("wprowadz nr karty: ");
                    cardNum = scan.nextInt();
                    System.out.println("wprowadz nr cvv karty: ");
                    cvv = scan.nextInt();
                    scan.nextLine();
                    System.out.println("wprowadz datę ważności karty: ");
                    exp_date = scan.nextLine();
                    URL url = new URL("http://localhost:8080/api/payments");

                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setDoOutput(true);



                    String json = "{\"cardNumber\":\"" + cardNum + "\"," +
                            "\"cvv\":\"" + cvv + "\"," +
                            "\"exp_date\":\"" + exp_date + "\"," +
                            "\"price\":\"" + priceSum + "\"" +
                            "}";

                    conn.getOutputStream().write(json.getBytes());
                    int responseCode = conn.getResponseCode();
                    if (responseCode == 200) {
                        System.out.println("Wysłano pomyślnie");
                    } else {
                        System.out.println("Błąd wysyłania");
                    }


                    break;
                }else if(platnosc == 2){
                    priceSum = priceSum + getSumPrice();
                    System.out.println("Wprowadź nr BLIK: ");
                    blikNum = scan.nextInt();

                    URL url = new URL("http://localhost:8080/api/paymentsBlik");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "text/plain");
                    conn.setDoOutput(true);


                    try (OutputStream os = conn.getOutputStream()) {
                        String body = String.valueOf(blikNum);
                        os.write(body.getBytes("utf-8"));
                    }

                    int responseCode = conn.getResponseCode();
                    if (responseCode == 200) {
                        System.out.println("Wysłano pomyślnie");
                    } else {
                        System.out.println("Błąd wysyłania: " + responseCode);
                    }

                    URL url1 = new URL("http://localhost:8080/api/paymentsPrice");
                    HttpURLConnection conn1 = (HttpURLConnection) url1.openConnection();
                    conn1.setRequestMethod("POST");
                    conn1.setRequestProperty("Content-Type", "text/plain");
                    conn1.setDoOutput(true);


                    try (OutputStream os = conn1.getOutputStream()) {
                        String body = String.valueOf(priceSum);
                        os.write(body.getBytes("utf-8"));
                    }

                    int responseCode1 = conn1.getResponseCode();
                    if (responseCode1 == 200) {
                        System.out.println("Wysłano pomyślnie");
                    } else {
                        System.out.println("Błąd wysyłania: " + responseCode1);
                    }
                    break;
                }




            } else{

                printProductCounts(productList);
                double rounded_price = Math.round(getSumPrice() * 100.0) / 100.0;
                System.out.println("cena: " + rounded_price);
                System.out.print("Zeskanuj kod lub wppisz \"card\" aby zapłacić kartą albo \"blik\" aby zaplacic blikiem \n");
                keyboardInput = scan.nextLine();

                checkInput(keyboardInput);

            }


            }
        }


    public static void printProductCounts(ArrayList<Product> productList) {
        Map<String,Integer> summedProducts = new HashMap<>();
        for(int i = 0;i<productList.size();i++){
            String name = productList.get(i).getName();
            summedProducts.put(name,summedProducts.getOrDefault(name,0)+1);
        }
        for(Map.Entry<String,Integer> entry : summedProducts.entrySet()){
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key + " x" + value);
        }
    }



    public static void checkInput(String scan) {
    int found = 0;
        for (int a = 0; a < codeList.size(); a++) {
            if (scan.equals(codeList.get(a))) {
                productList.add(new Product(nameList.get(a), priceList.get(a)));
                found = 1;
            }
        } if(found == 0 && scan.equals("card")) {
            System.out.println("placimy");
            platnosc = 1;


        }else if(found == 0 && scan.equals("blik")) {
            System.out.println("placimy");
            platnosc = 2;


        }else if(found == 0){
            System.out.println("invalid");
        }else{
            System.out.println("");
        }
    }
    public static double getSumPrice(){
        double summedPrice = 0;

        for(int i=0;i<productList.size();i++){
            summedPrice += productList.get(i).getPrice();
        }


        return summedPrice;
    }

}