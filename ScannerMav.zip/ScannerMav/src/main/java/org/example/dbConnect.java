package org.example;
import java.sql.*;
import java.util.ArrayList;

public class dbConnect {
    Connection connection;

    public dbConnect() {
        try {
            connection = DriverManager.getConnection(
                    "jdbc:mariadb://localhost:3306/products",
                    "root", ""
            );
        }catch (SQLException e) {
            System.out.println("Could not connect to database");
            e.printStackTrace();
        }

    }
    public ArrayList<String> getData(){
        ArrayList<String> ids = new ArrayList<>();
        try {

            Statement stmt = connection.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT * FROM productinfo");

            while (rs.next()) {
                ids.add(rs.getString("productID"));

            }


        }catch (SQLException e) {
            System.out.println("Could not read data from database");
            e.printStackTrace();
        }
        return ids;
    }
    public ArrayList<String> getName(){
        ArrayList<String> Names = new ArrayList<>();
        try {

            Statement stmt = connection.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT * FROM productinfo");

            while (rs.next()) {
                Names.add(rs.getString("productName"));

            }


        }catch (SQLException e) {
            System.out.println("Could not read data from database");
            e.printStackTrace();
        }
        return Names;
    }
    public ArrayList<String> getPrice(){
        ArrayList<String> Price = new ArrayList<>();
        try {

            Statement stmt = connection.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT * FROM productinfo");

            while (rs.next()) {
                Price.add(rs.getString("productPrice"));

            }


        }catch (SQLException e) {
            System.out.println("Could not read data from database");
            e.printStackTrace();
        }
        return Price;
    }



}
