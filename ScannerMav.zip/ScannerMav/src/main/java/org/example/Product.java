package org.example;

class Product {
    String name;
    String price;

    public Product(String name, String price) {
        this.name = name;
        this.price = price;
    }
    public double getPrice() {
        return Double.parseDouble(price);

    }
    public String getName() {
        return name;

    }

    @Override
    public String toString() {
        return "Product{" +
                "name='" + name + '\'' +
                ", price='" + price + '\'' +
                '}';
    }

    public String price() {
        return "Product{" +
                ", price='" + price + '\'' +
                '}';
    }
}
