package com.example.demo;

public class Card {
    int cardNumber = 0;
    double price = 0;

    String exp_date;
    int cvv;

    public Card(int cardNumber,int cvv,String exp_date,double price) {
        this.cardNumber = cardNumber;
        this.cvv=cvv;
        this.exp_date=exp_date;
        this.price = price;
    }
    public int getCardNumber() {
        return cardNumber;
    }

    public String getExp_date() {
        return exp_date;
    }

    public int getCvv() {
        return cvv;
    }

    public double getprice() {
        return price;
    }

}
