package com.example.demo;
import java.sql.*;

public class DBConnect {
    Connection con;
    public  DBConnect(){
        try{
            con = DriverManager.getConnection(
                    "jdbc:mariadb://localhost:3306/products",
                    "root", ""
            );
            System.out.println("Connected");
        }catch(SQLException e){
            System.out.println("Error");
        }
    }

    public String getData(){
        return "aaa";
    }







}
