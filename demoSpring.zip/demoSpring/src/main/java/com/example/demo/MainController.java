package com.example.demo;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Random;

@RestController
public class MainController {

    DBConnect db = new DBConnect();




//    @PostMapping("/api/payments")
//    public String pay(){
//        int cardNumber = 0;
//        String expireDate = "";
//        int cvv = 0;
//        double amount = 0;
//        db.getData();
//        return "dddd";
//    }
    @PostMapping("/api/payments")
    public String pay(@RequestBody Card paymentRequest) {
        System.out.println("Numer Karty: " + paymentRequest.getCardNumber());
        System.out.println("cvv: " + paymentRequest.getCvv());
        System.out.println("data waznosci: " + paymentRequest.getExp_date());
        System.out.println("Cena do zapłacenia: " + paymentRequest.getprice());

        int card__number = paymentRequest.getCardNumber();
        int cvv = paymentRequest.getCvv();
        double price = paymentRequest.getprice();
        BankDbApplication.get_money_from_bankdb(price,cvv,card__number);

        return "Dane otrzymano";
    }
    @PostMapping("/send")
    public List<String> getData(){
        List<String> data = BankDbApplication.getUserData();
        return data;
    }
    @PostMapping("/getBlik")
    public String sendBlikNum(@RequestParam String number) {
        BankDbApplication.dropBliks();
        Random random = new Random();
        int blik1 = 100000 + random.nextInt(900000);
        String blik = String.valueOf(blik1);
        int parsedNumber = Integer.valueOf(number);
        System.out.println("Użytkownik o numerze: " + number + " otrzymał BLIK: " + blik);
        BankDbApplication.updateBlik(blik1,parsedNumber);


        return blik;
    }
    int blikNum = 0;
    double blikPrice = 0.0d;

    public void useBlikAndPrice(int blikNum, double blikPrice){
        BankDbApplication.get_money_from_bankdb(blikNum,blikPrice);
    }
    @PostMapping("/api/paymentsBlik")
    public void receiveBlik(@RequestBody String body) {
        try {
            int blikCode = Integer.parseInt(body.trim());
            System.out.println("Otrzymano kod BLIK: " + blikCode);
            blikNum = blikCode;
            System.out.println(blikNum);


        } catch (NumberFormatException e) {
            System.err.println("Nieprawidłowy kod BLIK: " + body);
        }
    }


    @PostMapping("/api/paymentsPrice")
    public void receivePrice(@RequestBody String body) {
        try {
            double price = Double.parseDouble(body.trim());
            double roundedPrice = Math.round(price * 100.0) / 100.0;
            System.out.println("Cena: " + roundedPrice);
            blikPrice = roundedPrice;
            System.out.println(blikPrice);
            useBlikAndPrice(blikNum,blikPrice);


        } catch (NumberFormatException e) {
            System.err.println("Nieprawidłowa cena: " + body);
        }
    }






}
@Controller
class MainnController{
    @GetMapping("/mybank")
    public String products() {

        return "mainBank";


    }
}