package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

@SpringBootApplication
public class BankDbApplication {
    private static JdbcTemplate jdbcTemplate;

    public BankDbApplication(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public static void main(String[] args) {
        SpringApplication.run(BankDbApplication.class, args);
    }



    public static void get_money_from_bankdb(double price, int cvv, int card_number){
        String sql = "UPDATE konta \n" +
                "JOIN karty ON konta.ID = karty.ID_Konta\n" +
                "SET Saldo = Saldo - ?\n" +
                "WHERE karty.CVV = ?\n" +
                "AND karty.NumerKarty = ?;";
        jdbcTemplate.update(sql,price,cvv,card_number);
    }
    public static List<String> getUserData() {
        String sql = "SELECT Imie FROM klienci";
        List<String> data = jdbcTemplate.queryForList(sql, String.class);
        return data;
    }
    public static void updateBlik(int blik,int phone){
        String sql = "INSERT INTO blik \n" +
                "SET blik = ?, phone = ?;";
        jdbcTemplate.update(sql,blik,phone);
    }

    public static void get_money_from_bankdb(int blikNum, double blikPrice){
        String sql = "UPDATE konta\n" +
                "JOIN klienci ON klienci.ID = konta.ID_Klienta\n" +
                "JOIN blik ON blik.phone = klienci.Telefon\n" +
                "SET konta.Saldo = konta.Saldo - ?\n" +
                "WHERE blik.blik = ?;";
        jdbcTemplate.update(sql,blikPrice,blikNum);
    }
    public static void dropBliks(){
        String sql =  "TRUNCATE TABLE `bank`.`blik`";
        jdbcTemplate.update(sql);
    }



}

